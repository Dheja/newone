
package com.cg.nikhil.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "200",
    "400"
})
public class Responses {

    @JsonProperty("200")
    private com.cg.nikhil.pojo._200 _200;
    @JsonProperty("400")
    private com.cg.nikhil.pojo._400 _400;

    @JsonProperty("200")
    public com.cg.nikhil.pojo._200 get200() {
        return _200;
    }

    @JsonProperty("200")
    public void set200(com.cg.nikhil.pojo._200 _200) {
        this._200 = _200;
    }

    @JsonProperty("400")
    public com.cg.nikhil.pojo._400 get400() {
        return _400;
    }

    @JsonProperty("400")
    public void set400(com.cg.nikhil.pojo._400 _400) {
        this._400 = _400;
    }

}
