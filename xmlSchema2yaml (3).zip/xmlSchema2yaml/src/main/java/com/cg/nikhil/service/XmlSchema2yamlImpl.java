package com.cg.nikhil.service;

import org.springframework.stereotype.Service;

@Service
public class XmlSchema2yamlImpl implements IxmlSchema2yaml{

}
