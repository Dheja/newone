package com.cg.nikhil.controller;

import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.nikhil.pojo.Get;
import com.cg.nikhil.pojo.Items;
import com.cg.nikhil.pojo.Parameter;
import com.cg.nikhil.pojo.Post;
import com.cg.nikhil.pojo.Responses;
import com.cg.nikhil.pojo.Schema;
import com.cg.nikhil.pojo.SwaggerSchema;
import com.cg.nikhil.pojo._200;
import com.cg.nikhil.pojo._400;
import com.cg.nikhil.service.IxmlSchema2yaml;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.YAMLGenerator.Feature;

@RestController
public class xmlSchema2JavaController {

	@Autowired
	IxmlSchema2yaml ixmlSchema2yaml;

	private static final Logger LOGGER = LoggerFactory.getLogger(xmlSchema2JavaController.class);

	private static ObjectMapper mapper = new ObjectMapper(new YAMLFactory().disable(Feature.WRITE_DOC_START_MARKER));
	

	final static JsonNodeFactory factory = JsonNodeFactory.instance;

	@RequestMapping(value = "/swaggerapi", method = RequestMethod.POST, consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE })
	public SwaggerSchema printYAML(@RequestBody SwaggerSchema obj)
			throws JsonGenerationException, JsonMappingException, IOException {

		Set<Class<? extends Object>> entities = getclassdetails();

		ObjectNode paths = factory.objectNode();
		for (Class<? extends Object> entity : entities) {
			entity.getSimpleName();

			ObjectNode path = factory.objectNode();

			path.putPOJO("get", createDefaultGet(entity));
			path.putPOJO("post", createDefaultPost(entity));
			paths.set("SLASH" + entity.getSimpleName().toLowerCase(), path);
		}

		/*
		 * String slashEmployees(String) { return null; }
		 */

		obj.setPaths(paths);

		obj.setDefinitions(creteDefinitions());
		mapper.writeValue(System.out, obj);
		mapper.writeValueAsString(obj);
		try {
			FileWriter fw = new FileWriter("C:\\Users\\nsannadi\\testout.txt");
			fw.write(mapper.writeValueAsString(obj).replace("SLASH", "/"));
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return obj;
	}

	public static String getYAML(Object obj) throws JsonProcessingException {
		return mapper.writeValueAsString(obj);
	}

	/*
	 * @RequestMapping(value = "/postapi", method = RequestMethod.POST, consumes = {
	 * MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE }) public
	 * void printPost(@RequestBody Post obj) throws JsonGenerationException,
	 * JsonMappingException, IOException { mapper.writeValue(System.out, obj);
	 * 
	 * mapper.writeValueAsString(obj); try { FileWriter fw = new
	 * FileWriter("C:\\Users\\nsannadi\\Post.txt");
	 * fw.write(mapper.writeValueAsString(obj)); fw.close(); } catch (Exception e) {
	 * System.out.println(e); } System.out.println("Success..."); }
	 * 
	 * public static String getPost(Object obj) throws JsonProcessingException {
	 * return mapper.writeValueAsString(obj); }
	 */

	public Post createDefaultPost(Class<? extends Object> entity) throws JsonProcessingException {
		Post post = new Post();
		List<String> consumes = new ArrayList<>();
		consumes.add("application/xml");
		consumes.add("application/json");
		List<String> produces = new ArrayList<>();
		produces.add("application/xml");
		produces.add("application/json");
		post.setConsumes(consumes);
		post.setProduces(produces);
		post.setSummary("To Create a new record for the entity: " + entity.getSimpleName());
		post.setOperationId("postOperation" + entity.getSimpleName());
		Responses responses = new Responses();
		responses.set400(new _400());
		responses.set200(new _200());
		post.setResponses(responses);
		List<Parameter> parameters = new ArrayList<>();
		Parameter parameter = new Parameter();
		parameter.setDescription(entity.getSimpleName() + " Entity to be posted");
		parameter.setIn("body");
		parameter.setName(entity.getSimpleName());
		parameter.setRequired(true);
		Schema schema = new Schema();
		schema.set$ref("#/definitions/" + entity.getSimpleName());
		parameter.setSchema(schema);
		parameters.add(parameter);
		post.setParameters(parameters);
		return post;
	}
//--------------End of post-----------------------	

	/*
	 * @RequestMapping(value = "/getapi", method = RequestMethod.GET, consumes = {
	 * MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE }) public
	 * Get printGet(@RequestBody Get obj) throws JsonGenerationException,
	 * JsonMappingException, IOException { mapper.writeValue(System.out, obj);
	 * 
	 * mapper.writeValueAsString(obj); try { FileWriter fw = new
	 * FileWriter("C:\\Users\\nsannadi\\Post.txt");
	 * fw.write(mapper.writeValueAsString(obj)); fw.close(); } catch (Exception e) {
	 * System.out.println(e); } System.out.println("Success..."); return obj; }
	 * 
	 * public static String getPost(Object obj) throws JsonProcessingException {
	 * return mapper.writeValueAsString(obj); }
	 */

	public Get createDefaultGet(Class<? extends Object> entity) {

		String entityName = entity.getSimpleName();
		Get get = new Get();
		/*
		 * get.getDescription(); get.getOperationId(); get.getParameters();
		 * get.getProduces(); get.getResponses(); get.getSummary(); get.getSecurity();
		 */
		get.setSummary("To Create a new record for the entity" + entityName);
		get.setDescription(entityName + " Entity to be posted");
		get.setOperationId("getOperation" + entityName);
		// If Id of paramter is equal to
		List<Parameter> parameters = new ArrayList<>();
		// List<Parameter> parameters1=new ArrayList<>();
		Parameter parameter = new Parameter();
		parameter.setName(entityName);
		parameter.setIn("query");
		parameter.setDescription(entityName + " Entity to be Get");
		parameter.setRequired(true);
		parameter.setType("array");
		Items items = new Items();
		items.setType(items.getType().toLowerCase());
		parameter.setItems(items);
		
		/*
		 * for(Parameter fieldType:) {
		 * 
		 * }
		 */
		
		Schema schema = new Schema();
		schema.set$ref("#/definitions/" + entityName);
		parameter.setSchema(schema);
		parameters.add(parameter);
		get.setParameters(parameters);
		List<String> produces = new ArrayList<>();
		produces.add("application/xml");
		produces.add("application/json");
		get.setProduces(produces);
		Responses responses = new Responses();
		responses.set400(new _400());
		responses.set200(new _200());
		get.setResponses(responses);
		com.cg.nikhil.pojo.Security security = new com.cg.nikhil.pojo.Security();
		List<String> petstoreAuth = new ArrayList<>();

		security.setPetstoreAuth(petstoreAuth);
		// get.setSecurity(security);

		return get;
	}
	// --------------------End of Get------------------

	// --------Pet Definition--------------
	/*
	 * @RequestMapping(value = "/petdefprint") public Pet printPetDefinition()
	 * throws JsonGenerationException, JsonMappingException, IOException {
	 * 
	 * Pet pet = createDefaultPetDefinition("Requisitiuon"); try { FileWriter fw =
	 * new FileWriter("C:\\Users\\nsannadi\\Post1.txt");
	 * fw.write(mapper.writeValueAsString(pet)); fw.close(); } catch (Exception e) {
	 * System.out.println(e); } System.out.println("Success..."); return pet; }
	 * 
	 * public Pet createDefaultPetDefinition(String entityName) { Pet pet = new
	 * Pet();
	 * 
	 * com.cg.nikhil.pojo.Tags tags = new com.cg.nikhil.pojo.Tags();
	 * tags.setType(""); pet.setType("object"); return pet;
	 * 
	 * }
	 */
	public ObjectNode creteDefinitions() {

		Set<Class<? extends Object>> allPojos = getclassdetails();

		ObjectNode schema = factory.objectNode();

		for (Class<? extends Object> obj : allPojos) {
			ObjectNode entity = factory.objectNode();
			entity.put("type", "object");
			// entity.p
			ObjectNode properties = factory.objectNode();
			for (Field field : obj.getDeclaredFields()) {
				ObjectNode property = factory.objectNode();
				String type = getType(field.getType().getSimpleName());

				if ("object".equals(type)) {
					property.put("$ref", "#/definitions/" + field.getType().getSimpleName());
				} else {
					if(type != null) {
					property.put("type", type);
					}
				}
				properties.set(field.getName(), property);
			}
			entity.set("properties", properties);
			schema.set(obj.getSimpleName(), entity);

		}
		return schema;
	}

	String getType(String fieldType) {

		LOGGER.info("Field Type  " + fieldType.toLowerCase().toString());

		switch (fieldType.toLowerCase()) {

		case "string":
			return "string";
		case "biginteger":
			return "integer";
		case "integer":
			return "integer";
		case "list":
			return null;
		case "boolean":
			return "boolean";
		case "bigdecimal":
			return "integer";
		default:
			return "object";

		}

	}

	public Set<Class<? extends Object>> getclassdetails() {
		Reflections reflections = new Reflections("com.cg.nikhil.entity", new SubTypesScanner(false));
		return reflections.getSubTypesOf(Object.class);

	}

}
