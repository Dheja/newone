package com.cg.airlines_reservation_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.airlines_reservation_system.entity.FlightInformation;
import com.cg.airlines_reservation_system.service.IFlightService;

@RestController

public class Controller {
	@Autowired
	private IFlightService fs;

	@RequestMapping(value = "/createFlight", method = RequestMethod.POST)
	public FlightInformation createFlight(@RequestBody FlightInformation flight) {

		return fs.createFlight(flight);
	}

	@RequestMapping(value = "/getFlightById/{flightId}")
	public FlightInformation getFlightById(@PathVariable("flightId") int flightId) {

		return fs.getFlightById(flightId);
	}

	@RequestMapping("/getAllFlights")
	public List<FlightInformation> getAllFlights() {
		return fs.getAllFlights();
	}

	@RequestMapping(value = "/deleteFlight/{flightId}", method = RequestMethod.DELETE)
	public String deleteFlight(@PathVariable("flightId") int flightId) {
		return fs.deleteFlight(flightId);
	}

	/*
	 * @PutMapping(value=
	 * "flight/{flightId}/{depDate}/{arrDate}/{depTime}/{arrTime}") public
	 * FlightInformation updateFlight(@PathVariable("flightId") int flightId,
	 * 
	 * @PathVariable("depDate") String depDate,@PathVariable("arrDate") String
	 * arrDate,
	 * 
	 * @PathVariable("depTime") String depTime,@PathVariable("arrTime") String
	 * arrTime) { depDate = depDate.replace('-','/'); arrDate =
	 * arrDate.replace('-','/'); return
	 * fs.updateFlight(flightId,depDate,arrDate,depTime,arrTime); }
	 */

	@PutMapping(value = "/flight/{flightId}/{depDate}/{arrDate}/{depTime}/{arrTime}")
	public FlightInformation updateFlight(@PathVariable("flightId") int flightId,

			@PathVariable("depDate") String depDate, @PathVariable("arrDate") String arrDate,
			@PathVariable("depTime") String depTime, @PathVariable("arrTime") String arrTime) {
		depDate = depDate.replace('-', '/');
		arrDate = arrDate.replace('-', '/');
		return fs.updateFlight(flightId, depDate, arrDate, depTime, arrTime);
	}

}
