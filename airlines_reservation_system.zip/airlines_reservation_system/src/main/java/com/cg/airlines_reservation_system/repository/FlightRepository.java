package com.cg.airlines_reservation_system.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.airlines_reservation_system.entity.FlightInformation;

public interface FlightRepository extends JpaRepository<FlightInformation, Integer>{

	@Query("SELECT f from FlightInformation f where f.depDate=:depDate and f.arrCity=:arrCity")
	List<FlightInformation> getParticularFlights(@Param(value="depDate") String depDate,
			@Param(value="arrCity") String arrCity);

	
	
	
	

}
