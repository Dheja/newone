package com.cg.airlines_reservation_system.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

public class AirlinesExceptionHandler {

private final Logger slf4jLogger = LoggerFactory.getLogger(this.getClass());
	
    @ExceptionHandler(value = AirlinesException.class)  
    public ResponseEntity<AirlinesException> handleBaseException(AirlinesException e){     	
    	
    	slf4jLogger.error("Checked exception occurred",e);
    	AirlinesException result = new AirlinesException(e.getCode(), e.getMessage());
    	if(e.getCode() == 204) {
    		return new ResponseEntity<>(result,HttpStatus.NO_CONTENT);
    	}
    		else {
			 
    		return new ResponseEntity<>(result,HttpStatus.INTERNAL_SERVER_ERROR);
    	}

    } 
	
}
