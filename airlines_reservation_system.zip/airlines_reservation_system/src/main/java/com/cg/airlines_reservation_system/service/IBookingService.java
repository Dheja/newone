package com.cg.airlines_reservation_system.service;

import java.util.List;
import java.util.Optional;

import com.cg.airlines_reservation_system.entity.BookingInformation;

public interface IBookingService {

	
	public Optional<BookingInformation> getbooking(int bookingId);

	

	
	BookingInformation bookFlight(BookingInformation book, int flightId);



	public List<BookingInformation> getAllBookings();

	public List<BookingInformation> getBookingsById(int flightId);




	public String deleteFlight(int bookingId);




	public BookingInformation updateBooking(int bookingId, String custEmail, int noOfPassengers,
			String classType);




	public BookingInformation bookFlight(BookingInformation book);

}
