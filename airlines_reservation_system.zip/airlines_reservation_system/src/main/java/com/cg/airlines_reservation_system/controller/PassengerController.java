package com.cg.airlines_reservation_system.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.airlines_reservation_system.entity.BookingInformation;
import com.cg.airlines_reservation_system.entity.FlightInformation;
import com.cg.airlines_reservation_system.service.IBookingService;
import com.cg.airlines_reservation_system.service.IFlightService;

@RestController
public class PassengerController {
	
	@Autowired
	private IFlightService fs;
	
	@Autowired
	private IBookingService bs;
	
	@RequestMapping("/flights/{depDate}/{arrCity}")
		public List<FlightInformation> getParticularFlights(@PathVariable String depDate,@PathVariable String arrCity){
		depDate = depDate.replace('-','/');	
		return fs.getParticularFlights(depDate,arrCity);}
	
	@PostMapping(value="/flight/bookFlight")
	public BookingInformation bookFlight(@RequestBody BookingInformation book) {
		return bs.bookFlight(book);
		
	}
	
	@RequestMapping(value="/bookings/{bookingId}")
	public Optional<BookingInformation> getbooking(@PathVariable int bookingId) {
		return bs.getbooking(bookingId);
	}
	@RequestMapping(value="/bookings{flightId}")
	public List<BookingInformation> getBookingsById(@PathVariable("flightId") int flightId) {
		return bs.getBookingsById(flightId);
	}
	@RequestMapping("/allbookings")
	public List<BookingInformation> getAllBookings() {
		return bs.getAllBookings();
	}
	
	@RequestMapping(value = "/deletebooking/{bookingId}", method = RequestMethod.DELETE)
	public String deleteFlight(@PathVariable("bookingId") int bookingId) {
		return bs.deleteFlight(bookingId);
	}

	@PutMapping(value = "/updateBooking/{bookingId}/{custEmail}/{noOfPassengers}/{classType}")
	public BookingInformation updateBooking(@PathVariable("flightId") int flightId,

			@PathVariable("bookingId") int bookingId, @PathVariable("custEmail") String custEmail,
			@PathVariable("noOfPassengers") int noOfPassengers, @PathVariable("classType") String classType) {
		return bs.updateBooking(bookingId, custEmail, noOfPassengers, classType);
	}

}
