package com.cg.airlines_reservation_system.entity;

import lombok.Data;

@Data
public class CommonData extends FlightInformation {
	
	private int flightId;
	private String airline;
	private int noOfPassengers;
	private String classType;
	private float totalFare;
	private String arrCity;
	private String arrDate;
	private String depDate;
	private String depTime;
	private String arrTime;
	private int firstSeats;
	private int firstSeatsFare;
	private int businessSeats;
	private int businessSeatsFare;
}
