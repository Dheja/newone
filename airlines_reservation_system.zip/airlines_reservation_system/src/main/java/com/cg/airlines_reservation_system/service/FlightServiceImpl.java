package com.cg.airlines_reservation_system.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.airlines_reservation_system.entity.FlightInformation;
import com.cg.airlines_reservation_system.repository.FlightRepository;

@Service
public class FlightServiceImpl implements IFlightService {

	@Autowired
	private FlightRepository fr;

	@Override
	public List<FlightInformation> getAllFlights() {

		return fr.findAll();
	}

	@Override
	public FlightInformation createFlight(FlightInformation flight) {
		return fr.save(flight);
		}

	@Override
	public String deleteFlight(int flightId) {
		fr.deleteById(flightId);
		return "Flight Details Deleted Successfully";
		
	}

	

	@Override
	public List<FlightInformation> getParticularFlights(String depDate, String arrCity) {
		return fr.getParticularFlights(depDate,arrCity);	
	}

	@Override
	public FlightInformation getFlightById(int flightId) {
	return fr.getOne(flightId);
	}

	
	

	@Override
	public FlightInformation updateFlight(int flightId, String depDate, String arrDate, String depTime,
			String arrTime) {
		FlightInformation updated = fr.getOne(flightId);
		  updated.setDepDate(depDate); updated.setArrDate(arrDate);
		  updated.setDepTime(depTime); updated.setArrTime(arrTime); 
		  return fr.save(updated);
		  
	}

}
	 
	





