package com.cg.airlines_reservation_system.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.airlines_reservation_system.entity.BookingInformation;
import com.cg.airlines_reservation_system.entity.CommonData;
import com.cg.airlines_reservation_system.entity.FlightInformation;
import com.cg.airlines_reservation_system.repository.BookingRepository;
import com.cg.airlines_reservation_system.repository.FlightRepository;

@Service
public class BookingServiceImpl implements IBookingService {

	@Autowired
	private BookingRepository br;
	
	@Autowired
	private FlightRepository fr;
	



	/*
	 * @Override public BookingInformation bookFlight(int flightId,
	 * BookingInformation book) { FlightInformation flight = fr.getOne(flightId);
	 * book.setFlight(flight); return br.saveAll(flight);
	 * 
	 * }
	 * 
	 */


	@Override
	public BookingInformation bookFlight(BookingInformation book ,int flightId) {
		FlightInformation flight= fr.getOne(flightId);
		book.setDestCity(flight.getDepCity());
		book.setTotalFare(flight.getFirstSeatsFare()*book.getNoOfPassengers());
		book.setClassType("firstSeats");
		book.setFlight(flight);
		
		return br.save(book);
	}




	@Override
	public Optional<BookingInformation> getbooking(int bookingId) {
		// TODO Auto-generated method stub
		return br.findById(bookingId);
	}




	@Override
	public List<BookingInformation> getAllBookings() {
		return br.findAll();
	}




	
	 



	  @Override public List<BookingInformation> getBookingsById(int flightId)
	  {
		 List<BookingInformation> bookings = new ArrayList<>();  
		
		 return br.findByflightId(flightId);
		  
		   
		  
	  }




	@Override
	public String deleteFlight(int bookingId) {
		 br.deleteById(bookingId);
		 return "Ticket deleted successfully";
	}




	@Override
	public BookingInformation updateBooking(int bookingId, String custEmail, int noOfPassengers,
			String classType) {
		BookingInformation updated = br.getOne(bookingId);
		  updated.setBookingId(bookingId);
		  updated.setCustEmail(custEmail);
		  updated.setNoOfPassengers(noOfPassengers);
		  updated.setClassType(classType);
		return br.save(updated);
		  
	}




	@Override
	public BookingInformation bookFlight(BookingInformation book) {
		return br.save(book);
	}




	



}