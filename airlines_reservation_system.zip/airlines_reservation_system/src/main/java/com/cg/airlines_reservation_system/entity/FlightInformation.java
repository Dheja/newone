package com.cg.airlines_reservation_system.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.AbstractPersistable;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "FlightInformation")

public class FlightInformation implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "flight_seq")
	@SequenceGenerator(name = "flight_seq", sequenceName = "flight_seq", allocationSize = 1, initialValue = 100)
	@Column(name = "flight_id")
	private int flightId;
	
	@Column(name = "flight_name",nullable=false)
	private String airline;
	
	@Column(name = "departure_city",nullable=false)
	private String depCity;
	
	@Column(name = "arrival_city",nullable=false)
	private String arrCity;
	
	@Column(name = "arrival_date",nullable=false)
	private String arrDate;
	
	@Column(name = "departure_date",nullable=false)
	private String depDate;
	
	@Column(name = "departure_time",nullable=false)
	private String depTime;
	
	@Column(name = "arrival_time",nullable=false)
	private String arrTime;
	
	@Column(name = "first_seats",nullable=false)
	private int firstSeats;

	@Column(name = "firstseats_fare",nullable=false)
	private int firstSeatsFare;
	
	@Column(name = "buss_seats",nullable=false)
	private int businessSeats;
	
	@Column(name = "buss_fare",nullable=false)
	private int businessSeatsFare;

	
	@JsonIgnore
	@OneToMany(targetEntity = BookingInformation.class, mappedBy = "flight", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	
	private List<BookingInformation> bookInfo=new ArrayList<>();

	
	}



