package com.cg.airlines_reservation_system.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.airlines_reservation_system.entity.BookingInformation;

@Repository
public interface BookingRepository extends JpaRepository<BookingInformation, Integer> {

	/*
	 * @Query("select b from BookingInformation b where b.flightId=:flightId")
	 * Optional<BookingInformation> getAllBookingsById(int flightId);
	 */

	public List<BookingInformation> findByflightId(int flightId);

}
