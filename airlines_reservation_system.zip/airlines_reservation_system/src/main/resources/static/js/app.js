function validate(){
	var username= document.getElementById('name');
	var password =document.getElementById('password');
	if(username=="sai"&&password=="chandu"){
		return true;
	}else{
		alert("please enter valid credentials")
	}
	
	
}