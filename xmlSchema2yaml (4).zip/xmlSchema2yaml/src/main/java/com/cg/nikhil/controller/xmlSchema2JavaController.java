package com.cg.nikhil.controller;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.nikhil.pojo.Get;
import com.cg.nikhil.pojo.Items;
import com.cg.nikhil.pojo.Parameter;
import com.cg.nikhil.pojo.Pet;
import com.cg.nikhil.pojo.Post;
import com.cg.nikhil.pojo.Responses;
import com.cg.nikhil.pojo.Schema;
import com.cg.nikhil.pojo.SwaggerSchema;
import com.cg.nikhil.pojo._200;
import com.cg.nikhil.pojo._400;
import com.cg.nikhil.service.IxmlSchema2yaml;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

@RestController
public class xmlSchema2JavaController {

	@Autowired
	IxmlSchema2yaml ixmlSchema2yaml;

	private static ObjectMapper mapper = new ObjectMapper(new YAMLFactory());

	@RequestMapping(value = "/swaggerapi", method = RequestMethod.POST, consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE })
	public void printYAML(@RequestBody SwaggerSchema obj)
			throws JsonGenerationException, JsonMappingException, IOException {
		mapper.writeValue(System.out, obj);

		mapper.writeValueAsString(obj);
		try {
			FileWriter fw = new FileWriter("C:\\Users\\nsannadi\\testout.txt");
			fw.write(mapper.writeValueAsString(obj));
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Success...");
	}

	public static String getYAML(Object obj) throws JsonProcessingException {
		return mapper.writeValueAsString(obj);
	}

	/*
	 * @RequestMapping(value = "/postapi", method = RequestMethod.POST, consumes = {
	 * MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE }) public
	 * void printPost(@RequestBody Post obj) throws JsonGenerationException,
	 * JsonMappingException, IOException { mapper.writeValue(System.out, obj);
	 * 
	 * mapper.writeValueAsString(obj); try { FileWriter fw = new
	 * FileWriter("C:\\Users\\nsannadi\\Post.txt");
	 * fw.write(mapper.writeValueAsString(obj)); fw.close(); } catch (Exception e) {
	 * System.out.println(e); } System.out.println("Success..."); }
	 * 
	 * public static String getPost(Object obj) throws JsonProcessingException {
	 * return mapper.writeValueAsString(obj); }
	 */

//-------------For Post--------------
	@RequestMapping(value = "/postprint")
	public Post printPostDemo() throws JsonGenerationException, JsonMappingException, IOException {

		Post post = createDefaultPost("Requisition");
		try {
			FileWriter fw = new FileWriter("C:\\Users\\nsannadi\\Post1.txt");
			fw.write(mapper.writeValueAsString(post));
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Success...");
		return post;
	}

	public Post createDefaultPost(String entityName) throws JsonProcessingException {
		Post post = new Post();
		List<String> consumes = new ArrayList<>();
		consumes.add("application/xml");
		consumes.add("application/json");
		List<String> produces = new ArrayList<>();
		produces.add("application/xml");
		produces.add("application/json");
		post.setConsumes(consumes);
		post.setProduces(produces);
		post.setSummary("To Create a new record for the entity " + entityName);
		post.setOperationId("postOperation" + entityName);
		Responses responses = new Responses();
		responses.set400(new _400());
		responses.set200(new _200());
		post.setResponses(responses);
		List<Parameter> parameters = new ArrayList<>();
		Parameter parameter = new Parameter();
		parameter.setDescription(entityName + " Entity to be posted");
		parameter.setIn("body");
		parameter.setName(entityName);
		parameter.setRequired(true);
		Schema schema = new Schema();
		schema.set$ref("#/definitions/" + entityName);
		parameter.setSchema(schema);
		parameters.add(parameter);
		post.setParameters(parameters);
		return post;
	}
//--------------End of post-----------------------	

	/*
	 * @RequestMapping(value = "/getapi", method = RequestMethod.GET, consumes = {
	 * MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE }) public
	 * Get printGet(@RequestBody Get obj) throws JsonGenerationException,
	 * JsonMappingException, IOException { mapper.writeValue(System.out, obj);
	 * 
	 * mapper.writeValueAsString(obj); try { FileWriter fw = new
	 * FileWriter("C:\\Users\\nsannadi\\Post.txt");
	 * fw.write(mapper.writeValueAsString(obj)); fw.close(); } catch (Exception e) {
	 * System.out.println(e); } System.out.println("Success..."); return obj; }
	 * 
	 * public static String getPost(Object obj) throws JsonProcessingException {
	 * return mapper.writeValueAsString(obj); }
	 */

	@RequestMapping(value = "/getprint")
	public Get printGetDemo() throws JsonGenerationException, JsonMappingException, IOException {

		Get get = createDefaultGet("Requisitiuon");
		try {
			FileWriter fw = new FileWriter("C:\\Users\\nsannadi\\Post1.txt");
			fw.write(mapper.writeValueAsString(get));
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Success...");
		return get;
	}

	public Get createDefaultGet(String entityName) {
		Get get = new Get();
		/*
		 * get.getDescription(); get.getOperationId(); get.getParameters();
		 * get.getProduces(); get.getResponses(); get.getSummary(); get.getSecurity();
		 */
		get.setSummary("To Create a new record for the entity" + entityName);
		get.setDescription(entityName + " Entity to be posted");
		get.setOperationId("postOperation" + entityName);
		List<Parameter> parameters = new ArrayList<>();
		// List<Parameter> parameters1=new ArrayList<>();
		Parameter parameter = new Parameter();
		parameter.setName(entityName);
		parameter.setIn("body");
		parameter.setDescription(entityName + " Entity to be posted");
		parameter.setRequired(true);
		parameter.setType("array");
		Items items = new Items();
		parameter.setItems(items);
		Schema schema = new Schema();
		schema.set$ref("#/definitaions/" + entityName);
		parameter.setSchema(schema);
		parameters.add(parameter);
		get.setParameters(parameters);
		List<String> produces = new ArrayList<>();
		produces.add("application/xml");
		produces.add("application/json");
		get.setProduces(produces);
		Responses responses = new Responses();
		responses.set400(new _400());
		responses.set200(new _200());
		get.setResponses(responses);
		com.cg.nikhil.pojo.Security security = new com.cg.nikhil.pojo.Security();
		List<String> petstoreAuth = new ArrayList<>();

		security.setPetstoreAuth(petstoreAuth);
		// get.setSecurity(security);

		return get;
	}
	// --------------------End of Get------------------

	// --------Pet Definition--------------
	@RequestMapping(value = "/petdefprint")
	public Pet printPetDefinition() throws JsonGenerationException, JsonMappingException, IOException {

		Pet pet = createDefaultPetDefinition("Requisitiuon");
		try {
			FileWriter fw = new FileWriter("C:\\Users\\nsannadi\\Post1.txt");
			fw.write(mapper.writeValueAsString(pet));
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Success...");
		return pet;
	}

	public Pet createDefaultPetDefinition(String entityName) {
		Pet pet = new Pet();

		com.cg.nikhil.pojo.Tags tags = new com.cg.nikhil.pojo.Tags();
		tags.setType("");
		pet.setType("object");
		return pet;

	}

}
