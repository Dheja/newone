package com.cg.nikhil.service;

public interface IxmlSchema2yaml {

}
