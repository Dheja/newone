package com.cg.yamlfileconversion.service;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Set;

import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;
import org.springframework.stereotype.Service;

import com.cg.yamlfileconversion.dto.YamlDto;

@Service
public class YamlServiceImpl implements YamlService {

	@Override
	public String getdetails(YamlDto dto) throws IOException {

		FileWriter fileW = new FileWriter("ABC.yml");
		// Initializing a BufferedWriter
		BufferedWriter buffW = new BufferedWriter(fileW);

		buffW.write("swagger: \"2.0\" ");
		buffW.newLine();
		buffW.write("info:");
		buffW.newLine();
		buffW.write("\t description: Regarding the pets details");
		buffW.newLine();
		buffW.write("\t version: " + dto.getVersion());
		buffW.newLine();
		buffW.write("\t title: " + dto.getTitle());
		buffW.newLine();
		buffW.write("host: " + dto.getHost());
		buffW.newLine();
		buffW.write("basePath: " + dto.getBasePath());
		buffW.newLine();
		buffW.write("\n");

		buffW.write("paths:");
		buffW.newLine();

		Set<Class<? extends Object>> allClasses = getclassdetails();
		for (Class<? extends Object> obj : allClasses) {

			buffW.write("\t /" + obj.getSimpleName().toLowerCase() + "/:");
			buffW.newLine();
			// get
			createGet(buffW, obj);
			createPost(buffW, obj);
			createPut(buffW, obj);
			createDelete(buffW, obj);

			// post

		}
		createDefinitions(buffW, allClasses);
		buffW.close();
		return "written successfully";

	}

	private void createDefinitions(BufferedWriter buffW, Set<Class<? extends Object>> allClasses) throws IOException {

		for (Class<? extends Object> obj : allClasses) {
			buffW.write("definitions: \n");
			buffW.write("\t " + obj.getSimpleName() + "\n");
			buffW.write("\t\t type: object\n");
			buffW.write("\t\t properties: \n");
			for (Field field : obj.getDeclaredFields()) {
				buffW.write("\t\t\t " + field.getName() + ": \n");
				buffW.write("\t\t\t\t type: " + simpleType(field.getType().toString()) + ": \n");
			}
		}
	}

	String simpleType(String type) {

		switch (type) {

		case "BigInteger":
			return "integer";
		case "String":
			return "string";
		case "Double":
			return "";
		case "Integer":
			return "integer";
		default:
			return null;
		}

	}

	private void createDelete(BufferedWriter buffW, Class<? extends Object> obj) throws IOException {
		buffW.write(" \t\t delete:");
		buffW.newLine();
		buffW.write("\t\t\t tags:");
		buffW.newLine();
		buffW.write("\t\t\t\t- " + obj.getSimpleName().toLowerCase());
		buffW.newLine();
		buffW.write("\t\t\t summary: Deletes an entity  " + obj.getSimpleName() + " with the give id");
		buffW.newLine();
		buffW.write("\t\t\t operationId: delete " + obj.getSimpleName());
		buffW.newLine();
		buffW.write("\t\t\t produces:");
		buffW.newLine();
		buffW.write("\t\t\t\t- application/xml \n");
		buffW.write("\t\t\t\t- application/json \n");
		buffW.write("\t\t\t parameters:");

		for (Field field : obj.getDeclaredFields()) {
			if (field.getName().contains("weight") || field.getName().contains("weight")) {
				buffW.newLine();
				buffW.write("\t\t\t\t- name: " + field.getName());
				buffW.newLine();
				buffW.write("\t\t\t\t\tin: query ");
				buffW.newLine();
				buffW.write("\t\t\t\t\ttype: " + field.getType().getSimpleName());
				buffW.newLine();
				buffW.write("\t\t\t\t\tdescription: Primarykey of the entity " + obj.getSimpleName());
				buffW.newLine();
				buffW.write("\t\t\t\t\trequired: true");
				buffW.newLine();

			}

		}
		buffW.write("\t\t\t responses:");
		buffW.newLine();
		buffW.write("\t\t\t\t 200:");
		buffW.newLine();
		buffW.write("\t\t\t\t\t description: Response is Ok \n");
		buffW.write("\t\t\t\t 400: \n");
		buffW.write("\t\t\t\t\t description: Invalid name supplied \n");
		buffW.write("\t\t\t\t 405: \n");
		buffW.write("\t\t\t\t\t description: Invalid input \n");

	}

	void createPut(BufferedWriter buffW, Class<? extends Object> obj) throws IOException {

		buffW.write(" \t\t put:");
		buffW.newLine();
		buffW.write("\t\t\t tags:");
		buffW.newLine();
		buffW.write("\t\t\t\t- " + obj.getSimpleName().toLowerCase());
		buffW.newLine();
		buffW.write("\t\t\t summary: Update an Existing" + obj.getSimpleName());
		buffW.newLine();
		buffW.write("\t\t\t operationId: update " + obj.getSimpleName());
		buffW.newLine();
		buffW.write("\t\t\t produces:");
		buffW.newLine();
		buffW.write("\t\t\t\t- application/xml \n");
		buffW.write("\t\t\t\t- application/json \n");
		buffW.write("\t\t\t parameters:");
		buffW.newLine();
		for (Field field : obj.getDeclaredFields()) {
			if (field.getName().contains("weight") || field.getName().contains("weight")) {
				buffW.newLine();
				buffW.write("\t\t\t\t- name: " + field.getName());
				buffW.newLine();
				buffW.write("\t\t\t\t\tin: query ");
				buffW.newLine();
				buffW.write("\t\t\t\t\ttype: " + field.getType().getSimpleName());
				buffW.newLine();
				buffW.write("\t\t\t\t\tdescription: Updating the " + obj.getSimpleName());
				buffW.newLine();
				buffW.write("\t\t\t\t\trequired: true");
				buffW.newLine();

			}
		}
		buffW.write("\t\t\t responses:");
		buffW.newLine();
		buffW.write("\t\t\t\t 400:");
		buffW.newLine();
		buffW.write("\t\t\t\t\t description: Invalid input supplied \n");
		buffW.write("\t\t\t\t 404: \n");
		buffW.write("\t\t\t\t\t description: pet not found \n");
		buffW.write("\t\t\t\t 405: \n");
		buffW.write("\t\t\t\t\t description: Validation Exception \n");

		buffW.newLine();
	}

	void createGet(BufferedWriter buffW, Class<? extends Object> obj) throws IOException {
		buffW.write(" \t\t get:");
		buffW.newLine();
		buffW.write("\t\t\t tags:");
		buffW.newLine();
		buffW.write("\t\t\t\t- " + obj.getSimpleName().toLowerCase());
		buffW.newLine();
		buffW.write("\t\t\t summary: Get" + obj.getSimpleName());
		buffW.newLine();
		buffW.write("\t\t\t operationId: " + obj.getSimpleName());
		buffW.newLine();
		buffW.write("\t\t\t produces:");
		buffW.newLine();
		buffW.write("\t\t\t\t- application/xml \n");
		buffW.write("\t\t\t\t- application/json \n");
		buffW.write("\t\t\t parameters:");

		for (Field field : obj.getDeclaredFields()) {
			buffW.newLine();
			buffW.write("\t\t\t\t- name: " + field.getName());
			buffW.newLine();
			buffW.write("\t\t\t\t\tin: query ");
			buffW.newLine();
			buffW.write("\t\t\t\t\ttype: " + field.getType().getSimpleName());
			buffW.newLine();
			buffW.write("\t\t\t\t\tdescription: Get the details" + obj.getSimpleName());
			buffW.newLine();
			buffW.write("\t\t\t\t\trequired: true");
			buffW.newLine();

		}
		buffW.write("\t\t\t responses:");
		buffW.newLine();
		buffW.write("\t\t\t\t 200:");
		buffW.newLine();
		buffW.write("\t\t\t\t\t description: Response is Ok \n");
		buffW.write("\t\t\t\t 400: \n");
		buffW.write("\t\t\t\t\t description: Invalid name supplied \n");
		buffW.write("\t\t\t\t 404: \n");
		buffW.write("\t\t\t\t\t description: Cat not found \n");
		buffW.newLine();
	}

	void createPost(BufferedWriter buffW, Class<? extends Object> obj) throws IOException {

		buffW.newLine();
		buffW.write(" \t\t post:");
		buffW.newLine();
		buffW.write("\t\t\t tags:");
		buffW.newLine();
		buffW.write("\t\t\t\t-" + obj.getSimpleName());
		buffW.newLine();
		buffW.write("\t\t\t summary: Add a" + obj.getSimpleName().toLowerCase() + "to the store");
		buffW.newLine();
		buffW.write("\t\t\t operationId: addC " + obj.getSimpleName().toLowerCase());
		buffW.newLine();
		buffW.write("\t\t\t produces:");
		buffW.newLine();
		buffW.write("\t\t\t\t- application/xml \n");
		buffW.write("\t\t\t\t- application/json \n");
		buffW.write("\t\t\t parameters:");

		for (Field field : obj.getDeclaredFields()) {
			buffW.newLine();
			buffW.write("\t\t\t\t- name: " + field.getName());
			buffW.newLine();
			buffW.write("\t\t\t\t\tin: query ");
			buffW.newLine();
			buffW.write("\t\t\t\t\ttype: " + field.getType().getSimpleName());
			buffW.newLine();
			buffW.write("\t\t\t\t\tdescription: Adding " + obj.getSimpleName());
			buffW.newLine();
			buffW.write("\t\t\t\t\trequired: true");
			buffW.newLine();

		}
		buffW.write("\t\t\t responses:");
		buffW.newLine();
		buffW.write("\t\t\t\t 200:");
		buffW.newLine();
		buffW.write("\t\t\t\t\t description: Response is Ok \n");
		buffW.write("\t\t\t\t 400: \n");
		buffW.write("\t\t\t\t\t description: Invalid name supplied \n");
		buffW.write("\t\t\t\t 405: \n");
		buffW.write("\t\t\t\t\t description: Invalid input \n");

	}

	public Set<Class<? extends Object>> getclassdetails() {
		Reflections reflections = new Reflections("com.cg.yamlfileconversion.model", new SubTypesScanner(false));
		return reflections.getSubTypesOf(Object.class);

	}
}