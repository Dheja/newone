package com.cg.yamlfileconversion.service;

import java.io.IOException;

import com.cg.yamlfileconversion.dto.YamlDto;


public interface YamlService {

	

	public String getdetails(YamlDto dto) throws IOException;
	

}
