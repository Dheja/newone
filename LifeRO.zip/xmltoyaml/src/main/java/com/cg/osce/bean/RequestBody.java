package com.cg.osce.bean;

public class RequestBody {
	private String description;
	private Content content;
}
