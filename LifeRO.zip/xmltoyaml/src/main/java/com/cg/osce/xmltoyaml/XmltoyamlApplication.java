package com.cg.osce.xmltoyaml;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Set;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.osce.bean.Components;
import com.cg.osce.bean.Delete;
import com.cg.osce.bean.ExternalDocs;
import com.cg.osce.bean.Get;
import com.cg.osce.bean.Info;
import com.cg.osce.bean.License;
import com.cg.osce.bean.MainClass;
import com.cg.osce.bean.Paths;
import com.cg.osce.bean.Post;
import com.cg.osce.bean.Put;
import com.cg.osce.bean.Servers;
import com.cg.osce.bean.Tags;
import com.cg.osce.service.IYamlService;
import com.cg.osce.service.YamlServiceImpl;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.YAMLGenerator.Feature;

@SpringBootApplication
public class XmltoyamlApplication {

	public static void main(String[] args) {
		SpringApplication.run(XmltoyamlApplication.class, args);
		
		
		try {
			
			
			MainClass main1 = new MainClass();
			main1.setOpenapi("3.0.1");
			//Dto dto = new Dto();
		
			Info inf = new Info();
			inf.setTitle("SampleApi");
			inf.setDescription("This is a sample api description");
			inf.setTermsOfService("www.dheja.com");
			License license = new License();
			license.setName("Apache 2.0");
			license.setUrl("http://www.apache.org/licenses/LICENSE-2.0.html");
			inf.setLicense(license);
			inf.setVersion("1.0.0");
			/*
			 * inf.setBasepath("/yamlgen"); inf.setHost("www.swaggerYamlconverter.com");
			 */
			main1.setInfo(inf);
			ExternalDocs extDocs = new ExternalDocs();
			extDocs.setDescription("Find out more about Swagger");
			extDocs.setUrl("http://swagger.io");
			main1.setExternalDocs(extDocs);
			
			Servers servers = new Servers();
			
			servers.setUrl("https://sample.swagger.io");
			servers.setUrl("https://example.swagger.io");
			main1.setServers(servers);
			
			Tags tags = new Tags();
			tags.setName(null);
			tags.setDescription(null);
			tags.setExtDocs(extDocs);
			main1.setTags(tags);
			
			Paths paths = new Paths();
			
			Post post = new Post();
			post.setTags("tags");
			post.setSummary("Add a new song");
			post.setOperationId("addSong");
			post.setRequestBody(null);
			post.setResponses(null);
			post.setSecurity(null);
		
			
			Get get = new Get();
			get.setTags("tags");
			get.setSummary("Getting a song");
			get.setOperationId("getSong");
			get.setRequestBody(null);
			get.setResponses(null);
			get.setSecurity(null);
			
			Put put = new Put();
			put.setTags("tags");
			put.setSummary("Updating a song");
			put.setOperationId("update a song");
			put.setRequestBody(null);
			put.setResponses(null);
			put.setSecurity(null);
			
			Delete delete =new Delete();
			delete.setTags("tags");
			delete.setSummary("deleting a Song");
			delete.setOperationId("deleteSong");
			delete.setRequestBody(null);
			delete.setResponses(null);
			delete.setSecurity(null);
			
			paths.setPost(post);
			paths.setGet(get);
			paths.setPut(put);
			paths.setDelete(delete);
			main1.setPaths(paths);
			
			
			Components components =new Components();
			//Schemas schemas =new Schemas();
			
			
			
			
			
			
			
			
			/*
			 * Author authorobj = new Author(); authorobj.setFirstName("Ilaya");
			 * authorobj.setLastName("Raja"); schemas.setAuthorobj(authorobj); Song songobj=
			 * new Song(); songobj.setTitle("MounaRagam"); songobj.setYear(1956);
			 * songobj.setArtist("Sunitha"); schemas.setSongobj(songobj);
			 */
			  
			  components.setSchemas(null);
			  components.setSecuritySchemes(null);
			  main1.setComponents(components);
			
			  
			ObjectMapper mapper = new ObjectMapper(new YAMLFactory().disable(Feature.WRITE_DOC_START_MARKER));
			
			mapper.writeValue(new File("D:\\Users\\jpatcha\\Desktop\\accelarator\\xmltoyaml\\target\\dheja.yml"), main1);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		IYamlService yamlservice = new YamlServiceImpl();
		Set<Class<? extends Object>> allClasses = yamlservice.getclassdetails();
		for (Class<? extends Object> obj : allClasses) {

			String oo=obj.getSimpleName().toLowerCase();
			System.out.println(oo);
		Class cls=obj.getClass();
		Field[] fields = cls.getDeclaredFields();
		for(Field ff:fields) {
			System.out.println("variable name"+" "+ff.getName());
			System.out.println("Data type"+" "+ff.getType());
		}
		
		}
	}

}
