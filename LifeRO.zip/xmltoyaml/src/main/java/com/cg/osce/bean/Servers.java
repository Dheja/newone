package com.cg.osce.bean;

import lombok.Data;

@Data
public class Servers {

	private String url;
}
