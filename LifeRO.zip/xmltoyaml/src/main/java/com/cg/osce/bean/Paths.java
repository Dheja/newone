package com.cg.osce.bean;

import lombok.Data;

@Data
public class Paths {

	private Post post;
	private Get get;
	private Put put;
	private Delete delete;
}
