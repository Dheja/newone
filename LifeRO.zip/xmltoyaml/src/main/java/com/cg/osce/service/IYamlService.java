package com.cg.osce.service;

import java.io.IOException;
import java.util.Set;

import com.cg.osce.bean.Dto;


public interface IYamlService {
	public String getdetails(Dto dto)throws IOException;
	public Set<Class<? extends Object>> getclassdetails();
}
