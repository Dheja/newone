package com.cg.osce.bean;

import java.io.Serializable;

public class SecuritySchemas implements Serializable {
	
	private static final long serialVersionUID = 1L;
	ApiResponse ApiResponseObject;
}
