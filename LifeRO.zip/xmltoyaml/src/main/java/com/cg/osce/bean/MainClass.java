package com.cg.osce.bean;

import java.util.ArrayList;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class MainClass {
private String openapi;
private Info info;
private ExternalDocs externalDocs;
Object servers = new ArrayList<Object>();
Object tags = new ArrayList<Object>();
private Paths paths;
private Components components;





 
}



