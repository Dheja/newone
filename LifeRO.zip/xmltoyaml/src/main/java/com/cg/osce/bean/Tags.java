package com.cg.osce.bean;

import lombok.Data;

@Data
public class Tags {
	
	private String name;

	private String description;
	private ExternalDocs extDocs;
}
