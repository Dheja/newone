package com.cg.osce.bean;

import java.io.Serializable;

import lombok.Data;

@Data
public class License implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String name;
	private String url;
	
}
