package com.cg.osce.bean;

public class Content  {

	
}
