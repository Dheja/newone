package com.cg.osce.bean;

import lombok.Data;

@Data
public class Components {
		 
	Schemas schemas;
	SecuritySchemas securitySchemes;
}
