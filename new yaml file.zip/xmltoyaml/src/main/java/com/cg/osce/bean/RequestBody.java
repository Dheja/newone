package com.cg.osce.bean;

import java.util.List;

import lombok.Data;

@Data
public class RequestBody {
	private String description;
	private List<Content> content;
	private boolean required;
}
