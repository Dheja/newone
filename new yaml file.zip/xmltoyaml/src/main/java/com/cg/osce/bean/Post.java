package com.cg.osce.bean;

import java.io.Serializable;

import lombok.Data;

@Data
public class Post implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	public String tags;
	private String summary;
	private String operationId;
	private RequestBody requestBody;
	private Responses responses;
	private Security security;
	

}
