package com.cg.osce.bean;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "200",
    "404","405"
})
public class Responses {
	private _200 _200;
	private _404  _404;
	private _405 _405;
}