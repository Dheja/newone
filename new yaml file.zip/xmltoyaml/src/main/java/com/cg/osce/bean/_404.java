package com.cg.osce.bean;

import lombok.Data;

@Data
public class _404 {
	
	private String description;
	private Content content;
}
