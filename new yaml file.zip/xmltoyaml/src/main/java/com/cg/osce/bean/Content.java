package com.cg.osce.bean;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class Content  {

	List<String> content = new ArrayList<>();
	private Schema schema;
}
