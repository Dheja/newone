package com.cg.osce.service;

import java.util.Set;



public interface IYamlService {
	
	public Object getMethod(Class<? extends Object> pojo);

	public Object postMethod(Class<? extends Object> pojo);
	
	
	
	
	
	
	
	
	public Set<Class<? extends Object>> getclassdetails();

	public Object createComponents();

	
}
