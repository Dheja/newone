package com.cg.osce.bean;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.Data;

@Data
@Component
public class MainClass {
private String openapi;
private Info info;
private ExternalDocs externalDocs;
private Servers servers ;
private List<Tags> tags; 
private ObjectNode paths;
private Components components;
public void setPaths(ObjectNode paths2) {
	// TODO Auto-generated method stub
	
}
public List<String> setServers(List<String> servers2) {
	// TODO Auto-generated method stub
	return servers2;
}





 
}



