package com.cg.osce.bean;


import lombok.Data;

@Data

public class Dto {
		private String title;
		private String description;
		private String version;
		
		private String basepath;
		private String host;
		private String url;

	/*
	 * private String name;  private String type; private String
	 * format;
	 */}
