package com.cg.osce.bean;

import java.io.Serializable;

public class Schemas implements Serializable {

	
	private static final long serialVersionUID = 1L;

	
	
	/*
	 * IYamlService yamlservice = new YamlServiceImpl(); Set<Class<? extends
	 * Object>> allClasses = yamlservice.getclassdetails(); {for (Class<? extends
	 * Object> obj : allClasses) { obj.getSimpleName().toLowerCase();
	 * 
	 * } }
	 */






}
