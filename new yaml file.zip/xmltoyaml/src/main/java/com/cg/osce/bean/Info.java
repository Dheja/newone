package com.cg.osce.bean;


import lombok.Data;
@Data
public class Info {
	private String version;
	private String title;
	private String description;
	private String termsOfService;
	/*
	 * private String host; private String basepath;
	 */
	
	private License license;
	
}
