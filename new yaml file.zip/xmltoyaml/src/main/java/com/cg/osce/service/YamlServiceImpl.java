package com.cg.osce.service;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;
import org.springframework.stereotype.Service;

import com.cg.osce.bean.Content;
import com.cg.osce.bean.Dto;
import com.cg.osce.bean.Get;
import com.cg.osce.bean.Info;
import com.cg.osce.bean.License;
import com.cg.osce.bean.MainClass;
import com.cg.osce.bean.RequestBody;

import com.cg.osce.bean.Responses;
import com.cg.osce.bean.Schemas;

import com.cg.osce.bean.Schema;
import com.cg.osce.bean.Security;
import com.cg.osce.bean._404;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

@Service
public class YamlServiceImpl implements IYamlService {
	final static JsonNodeFactory factory = JsonNodeFactory.instance;
	

	/*
	 * public String getdetails(Dto dto) {
	 * 
	 * try { MainClass main1 = new MainClass(); main1.setOpenapi("3.0.0"); //Dto dto
	 * = new Dto();
	 * 
	 * Info inf = new Info(); inf.setTitle(dto.getTitle());
	 * inf.setDescription(dto.getDescription()); inf.setLicense(new License());
	 * inf.setVersion(dto.getVersion()); inf.setBasepath(dto.getBasepath());
	 * inf.setHost(dto.getHost()); main1.setInfo(inf);
	 * 
	 * ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
	 * mapper.writeValue(new
	 * File("C:\\Users\\Sai chandu\\Desktop\\accelarator\\xmltoyaml\\target\\dheja.yml"
	 * ), main1); } catch (JsonGenerationException e) { // TODO Auto-generated catch
	 * block e.printStackTrace(); } catch (JsonMappingException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } catch (IOException e) { //
	 * TODO Auto-generated catch block e.printStackTrace(); }
	 * 
	 * 
	 * 
	 * return "Yaml file written successfully"; }
	 */
	
	
	@Override
	public Object getMethod(Class<? extends Object> pojo) {
		
		
		
		

		String name = pojo.getSimpleName();
		Get get = new Get();
		get.setSummary("To fetch an entity" + name);
		get.setOperationId("get" + name);
		RequestBody requestBody = new RequestBody();
		requestBody.setDescription(name+"object to be fetched");
		
		Content content = new Content();
		
		/*
		 * List<Content> contents = new ArrayList<>();
		 * contents.addAll("application/xml"); Schema schema = new Schema();
		 * schema.set$ref("#/components/schemas/" + name); content.setSchema(schema);
		 * content.setContent(contents); requestBody.setContent(contents);
		 * 
		 * requestBody.setRequired(true); get.setRequestBody(requestBody);
		 */
		
		
		Responses responses = new Responses();
		com.cg.osce.bean._200 response200 =new com.cg.osce.bean._200();
		response200.setDescription("The required"+name+"is fetched successfully");
		response200.setContent(content);
		responses.set_200(response200);
		com.cg.osce.bean._404 response404 =new com.cg.osce.bean._404();
		response404.setDescription("The required"+name+"is not found");
		response404.setContent(content);
		responses.set_404(response404);
		get.setResponses(responses);
		
		Security security = new Security();
		String auth=name+"Auth";
		
		List<String> auth1= new ArrayList<>();
		security.setSecurityAuth(auth1);
		get.setSecurity(security);
		return get;

	}

	@Override
	public Object postMethod(Class<? extends Object> pojo) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
	 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public Set<Class<? extends Object>> getclassdetails() {
		Reflections reflections = new Reflections("com.cg.osce.model", new SubTypesScanner(false));
		return reflections.getSubTypesOf(Object.class);

	}

	@Override
	public Object createComponents() {
		Set<Class<? extends Object>> allPojos = getclassdetails();

		ObjectNode schema = factory.objectNode();

		for (Class<? extends Object> obj : allPojos) {
			ObjectNode entity = factory.objectNode();
			entity.put("type", "object");
			// entity.p
			ObjectNode properties = factory.objectNode();
			for (Field field : obj.getDeclaredFields()) {
				ObjectNode property = factory.objectNode();
				String type = getType(field.getType().getSimpleName());

				if ("object".equals(type)) {
					property.put("$ref", "#/definitions/" + field.getType().getSimpleName());
				} else {
					if(type != null) {
					property.put("type", type);
					}
				}
				properties.set(field.getName(), property);
			}
			entity.set("properties", properties);
			schema.set(obj.getSimpleName(), entity);

		}
		return schema;
	}

	String getType(String fieldType) {

		//LOGGER.info("Field Type  " + fieldType.toLowerCase().toString());

		switch (fieldType.toLowerCase()) {

		case "string":
			return "string";
		case "biginteger":
			return "integer";
		case "integer":
			return "integer";
		case "list":
			return null;
		case "boolean":
			return "boolean";
		case "bigdecimal":
			return "integer";
		default:
			return "object";

		}

	}

	
}
