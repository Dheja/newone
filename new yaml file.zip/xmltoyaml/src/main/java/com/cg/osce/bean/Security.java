package com.cg.osce.bean;

import java.util.List;

import lombok.Data;

@Data
public class Security {
	private List<String> securityAuth = null;

}
