package com.cg.osce.bean;

import lombok.Data;

@Data
public class _200 {
	
	private String description;
	private Content content;
}
