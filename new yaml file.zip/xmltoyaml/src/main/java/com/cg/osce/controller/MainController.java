package com.cg.osce.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.osce.bean.Dto;
import com.cg.osce.service.YamlServiceImpl;

@RestController
public class MainController {
	
	@Autowired
	YamlServiceImpl service;

	 
	/*
	 * @RequestMapping(value= "/openapi", method= RequestMethod.GET) public String
	 * getdetails(@RequestBody Dto dto) throws IOException { return
	 * service.getdetails(dto); }
	 */
	 
}
