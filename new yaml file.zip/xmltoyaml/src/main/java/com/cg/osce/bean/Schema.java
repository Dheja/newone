package com.cg.osce.bean;

import lombok.Data;

@Data
public class Schema {
   public String get$ref() {
		return $ref;
	}

	public void set$ref(String $ref) {
		this.$ref = $ref;
	}

private String $ref;
}
