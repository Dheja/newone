package com.sappi.dw;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * Hello world!
 *
 */
@ComponentScan(basePackages = "com.test.projectstructure.*")
@EnableAutoConfiguration
@SpringBootApplication
public class App {

	final static JsonNodeFactory factory = JsonNodeFactory.instance;

	public static void main(String[] args)
			throws JAXBException, ParserConfigurationException, SAXException, IOException {
		SpringApplication.run(App.class);
		BufferedWriter functionWriter = new BufferedWriter(new FileWriter("D:\\misc\\function.txt"));
		Element rootElement = new Element();
		Map<String, String> attributes = new HashMap<>();
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader("D:\\misc\\input.txt"));
			String line = reader.readLine();
			int lineNo = 0;
			while (line != null) {
				System.out.println("Processing Line: " + lineNo + ", " + line);

				String[] splitLine = line.split("=", 2);

				if (splitLine.length >= 1) {
					mapping(splitLine[1], splitLine[0], rootElement, functionWriter, lineNo, attributes);

				}
				lineNo++;
				// read next line
				line = reader.readLine();
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		functionWriter.close();
		ObjectMapper mapper = new ObjectMapper();
		System.out.println(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(rootElement));

		ObjectNode rootNode = factory.objectNode();

		rootNode.set(rootElement.getName(), convert(rootElement, factory.objectNode()));
		String result = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(rootNode).replace("\"", "");
		for (String key : attributes.keySet()) {
			result = result.replace(key + " : {", key + " @(" + attributes.get(key) + ") : {");
		}
		result = result.replaceAll("\\[[0-9]\\]", "");
		System.out.println(result);
		try {
			// write converted json data to a file named "CountryGSON.json"
			FileWriter writer = new FileWriter("D:\\misc\\OriginalOutput.json");
			writer.write(result);
			writer.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private static ObjectNode convert(Element rootElement, ObjectNode rootNode) {

		if ("value".equals(rootElement.getType())) {
			rootNode.put(rootElement.getName(), rootElement.getValue());
		} else if (rootElement.hasChildren()) {
			for (Element element : rootElement.getChildren()) {
				if ("object".equals(element.getType())) {
					ObjectNode node = factory.objectNode();
					rootNode.set(element.getName(), convert(element, node));
				} else if ("value".equals(element.getType())) {
					rootNode.put(element.getName(), element.getValue());
				} else if ("array".equals(element.getType())) {
					/*ArrayNode node = factory.arrayNode();
					for (Element arrayElement : element.getChildren()) {
						node.add(convert(arrayElement, factory.objectNode()));
					}
					rootNode.set(element.getName(), node);*/
					for (Element arrayElement : element.getChildren()) {
						rootNode.set(arrayElement.getName(), convert(arrayElement, factory.objectNode()));
					}
					
				}
			}
		}

		return rootNode;

	}

	private static void mapping(String source, String target, Element currElement, BufferedWriter functionWriter,
			int lineNo, Map<String, String> attributes) throws IOException {

		Element tempElement = null;
		String[] elementNames = target.substring(1).split("/");
		int length = elementNames.length;
		int depth = 1;
		for (String elementName : elementNames) {

			if (currElement.getName() == null) {
				currElement.setName(elementName);
				currElement.setDepth(depth);
				currElement.setValue(getValue(source, functionWriter, lineNo));
				currElement.setType(length == depth ? "value" : "object");
				continue;
			} else if (currElement.getName().equals(elementName)) {
				continue;
			} else if ((tempElement = getChildElement(currElement, elementName)) != null) {
				currElement = tempElement;
				depth++;
				continue;
			} else if (elementName.contains("[")) {
				Element arrayElement = null;
				String tempElementName = elementName.substring(0, elementName.length() - 3);
				tempElement = getChildElement(currElement, tempElementName);
				if (!"array".equals(tempElement.getType())) {
					tempElement.setType("array");
					Element zeroElement = new Element();
					zeroElement.setName(tempElementName + "[0]");
					zeroElement.setType("object");
					zeroElement.addChildren(tempElement.getChildren());
					tempElement.setChildren(null);
					tempElement.addChildren(zeroElement);
				} else if ((arrayElement = getChildElement(tempElement, elementName)) != null) {
					currElement = arrayElement;
					depth++;
					continue;
				} else {
					arrayElement = new Element();
					arrayElement.setName(elementName);
					arrayElement.setType("object");
					tempElement.addChildren(arrayElement);
					currElement = arrayElement;
					depth++;
				}

			} else {
				Element element = new Element();
				element.setName(elementName);
				element.setValue(getValue(source, functionWriter, lineNo));
				element.setDepth(++depth);
				if (length == depth && elementName.startsWith("@")) {
					element.setType("attribute");
					if (attributes.containsKey(currElement.getName())) {
						attributes.replace(currElement.getName(), attributes.get(currElement.getName())
								.concat(", "+elementName.substring(1) + ":" + element.getValue()));
					} else
						attributes.put(currElement.getName(), elementName.substring(1) + ":" + element.getValue());
				} else
					element.setType(length == depth ? "value" : "object");
				currElement.addChildren(element);
				//currElement.setType("object");
				currElement = element;
			}
		}
	}

	private static Element getChildElement(Element currElement, String elementName) {

		List<Element> elements = currElement.getChildren();
		if (elements == null)
			return null;
		for (Element element : elements) {
			if (element.getName().equals(elementName)) {
				return element;
			}
		}
		return null;
	}

	private static String getValue(String source, BufferedWriter functionWriter, int lineNo) throws IOException {
		if (source.startsWith("FixValues")) {
			String funVar = source.substring(source.indexOf("value") + 7, source.indexOf("value") + 7 + 5);
			fixedValues(source, funVar, functionWriter, lineNo);
			return "fun(" + funVar + ")";
		} else if (source.startsWith("ifWithoutElse")) {
			String funVar = source.substring(source.indexOf("value") + 7, source.indexOf("value") + 7 + 5);
			fixedValues(source, funVar, functionWriter, lineNo);
			return "fun(" + funVar + ")";
		} else if (source.startsWith("TransformDate")) {
			String[] transformDateArr = source.split(",");
			TransformDate(transformDateArr, functionWriter, lineNo);
			return transformDateArr[0].replace("/", ".") + ")";
		} else if (source.startsWith("formatWithLeadingZeros")) {
			String[] LeadingZerosDateArr = source.split(",");
			formatWithLeadingZeros(LeadingZerosDateArr, functionWriter, lineNo);
			return source.replace("/", ".");
		} else if (source.startsWith("/")) {
			String source1 = source.replace("/", ".");
			return "payload" + source1;
		} else {
			return (String) source.subSequence(12, source.length() - 2);
		}

	}

	private static void fixedValues(String source, String funVar, BufferedWriter functionWriter, int lineNo)
			throws IOException {

		int[] occurances = new int[10];
		int i = 0;
		int j = 0;

		do {
			occurances[i] = source.indexOf("FixedValues", j);
			if (occurances[i] > 0) {
				String subStr = source.substring(occurances[i]);
				String fiexdValues = subStr.substring(subStr.indexOf('{'), subStr.indexOf('}'));
				String vmDefault = "";
				funFixedValues(fiexdValues, vmDefault, funVar, functionWriter, lineNo);
				j = occurances[i++] + 10;
			} else {
				break;
			}
		} while (j < source.length());
	}

	private static void funFixedValues(String fiexdValues, String vmDefault, String funVar,
			BufferedWriter functionWriter, int lineNo) throws IOException {

		int i = 0;
		int j = 0;

		fiexdValues = fiexdValues.replace("{", "");
		if (fiexdValues.contains(":")) {
			fiexdValues = fiexdValues.substring(fiexdValues.indexOf(":"), fiexdValues.length());
		}
		String[] caseValues = fiexdValues.split(",");
		String[] leftValues = new String[caseValues.length];
		String[] rightValues = new String[caseValues.length];
		for (String str : caseValues) {
			String[] condetionValues = str.split("=");
			leftValues[i++] = condetionValues[0];
			rightValues[j++] = condetionValues[1];
		}
		lineNo++;
		functionWriter.write("Line No: " + lineNo + " %function fun(" + funVar + ")\n");
		functionWriter.write("{\n");
		functionWriter.write("condition:\n");
		for (int k = 0; k < leftValues.length; k++) {
			try {
				functionWriter.write(funVar + ": " + "\"" + rightValues[k] + "\" when " + funVar + "== " + leftValues[k]
						+ " otherwise");
				functionWriter.write("\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		functionWriter.write("}\n");
		functionWriter.write("\n");
	}

	private static void TransformDate(String[] transformDateArr, BufferedWriter functionWriter, int lineNo)
			throws IOException {

		lineNo++;
		functionWriter.write("Line No: " + lineNo + " fun TransformDate(date)=\n");
		functionWriter.write("{\n");
		String iform = "";
		String oform = "";
		for (String dateConversion : transformDateArr) {
			if (dateConversion.trim().startsWith("iform")) {
				String[] iformSplit = dateConversion.split("=");
				iform = iformSplit[1];
			}
			if (dateConversion.trim().startsWith("oform")) {
				String[] oformSplit = dateConversion.split("=");
				oform = oformSplit[1];
			}
		}
		functionWriter.write("date as Date {format: " + iform + "}" + " as String {format: " + oform + "}");
		functionWriter.write("\n}\n");
		functionWriter.write("\n\n");
	}

	private static void formatWithLeadingZeros(String[] leadingZerosDateArr, BufferedWriter functionWriter, int lineNo)
			throws IOException {
		String[] varNameArr = leadingZerosDateArr[0].split("/");
		String varName = varNameArr[varNameArr.length - 1];
		String[] valueArr = leadingZerosDateArr[1].split("=");
		int value = Integer.parseInt(valueArr[1].replace(")", "").trim());
		int decrementValue = value - 1;
		functionWriter.write("Line No: " + lineNo + " fun formatWithLeadingZeros(" + varName + "," + value + ") " + "= "
				+ varName + " as String{[format:" + "\"" + "0000000000" + "\"" + "[" + 0 + " to " + decrementValue
				+ "]}");
		functionWriter.write("\n\n");
	}

}
