package com.cg.osce.service;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Service;

import com.cg.osce.bean.Dto;
import com.cg.osce.bean.Info;
import com.cg.osce.bean.License;
import com.cg.osce.bean.MainClass;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

@Service
public class YamlServiceImpl implements IYamlService {

	public String getdetails(Dto dto) {
		/*
		 * try { MainClass main1 = new MainClass(); main1.setOpenapi("3.0.0"); //Dto dto
		 * = new Dto();
		 * 
		 * Info inf = new Info(); inf.setTitle(dto.getTitle());
		 * inf.setDescription(dto.getDescription()); inf.setLicense(new License());
		 * inf.setVersion(dto.getVersion()); inf.setBasepath(dto.getBasepath());
		 * inf.setHost(dto.getHost()); main1.setInfo(inf);
		 * 
		 * ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
		 * mapper.writeValue(new
		 * File("C:\\Users\\Sai chandu\\Desktop\\accelarator\\xmltoyaml\\target\\dheja.yml"
		 * ), main1); } catch (JsonGenerationException e) { // TODO Auto-generated catch
		 * block e.printStackTrace(); } catch (JsonMappingException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } catch (IOException e) { //
		 * TODO Auto-generated catch block e.printStackTrace(); }
		 */
			
	
		return "Yaml file written successfully";
	}

	

}
