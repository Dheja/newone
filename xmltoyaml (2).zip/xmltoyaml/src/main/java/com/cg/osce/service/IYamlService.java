package com.cg.osce.service;

import java.io.IOException;

import com.cg.osce.bean.Dto;


public interface IYamlService {
	public String getdetails(Dto dto)throws IOException;
	
}
