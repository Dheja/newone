package com.cg.osce.bean;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class MainClass {
private String openapi;
private Info info;
private ExternalDocs externalDocs;
private Servers servers;
private Tags tags;
private Paths paths;
private Components components;

 
}



