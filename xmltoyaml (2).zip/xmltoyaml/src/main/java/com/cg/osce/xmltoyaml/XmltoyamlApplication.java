package com.cg.osce.xmltoyaml;

import java.io.File;
import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.osce.bean.Delete;
import com.cg.osce.bean.Dto;
import com.cg.osce.bean.ExternalDocs;
import com.cg.osce.bean.Get;
import com.cg.osce.bean.Info;
import com.cg.osce.bean.License;
import com.cg.osce.bean.MainClass;
import com.cg.osce.bean.Paths;
import com.cg.osce.bean.Post;
import com.cg.osce.bean.Put;
import com.cg.osce.bean.Servers;
import com.cg.osce.bean.Tags;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

@SpringBootApplication
public class XmltoyamlApplication {

	public static void main(String[] args) {
		SpringApplication.run(XmltoyamlApplication.class, args);
		
		
		try {
			MainClass main1 = new MainClass();
			main1.setOpenapi("3.0.0");
			Dto dto = new Dto();
		
			Info inf = new Info();
			inf.setTitle("SampleApi");
			inf.setDescription("This is a sample api description");
			inf.setTermsOfService("www.dheja.com");
			inf.setLicense(new License());
			inf.setVersion("1.0.0");
			/*
			 * inf.setBasepath("/yamlgen"); inf.setHost("www.swaggerYamlconverter.com");
			 */
			main1.setInfo(inf);
			ExternalDocs extDocs = new ExternalDocs();
			extDocs.setDescription("Find out more about Swagger");
			extDocs.setUrl("http://swagger.io");
			main1.setExternalDocs(extDocs);
			
			Servers servers = new Servers();
			servers.setUrl("https://sample.swagger.io");
			servers.setUrl("https://example.swagger.io");
			main1.setServers(servers);
			
			Tags tags = new Tags();
			tags.setName(null);
			tags.setDescription(null);
			tags.setExtDocs(extDocs);
			main1.setTags(tags);
			
			Paths paths = new Paths();
			
			Post post = new Post();
			post.setTags("tags");
			post.setSummary("Add a new song");
			post.setOperationId("addSong");
			post.setRequestBody(null);
			post.setResponses(null);
			post.setSecurity(null);
		
			
			Get get = new Get();
			get.setTags("tags");
			get.setSummary("Getting a song");
			get.setOperationId("getSong");
			get.setRequestBody(null);
			get.setResponses(null);
			get.setSecurity(null);
			
			Put put = new Put();
			put.setTags("tags");
			put.setSummary("Updating a song");
			put.setOperationId("update a song");
			put.setRequestBody(null);
			put.setResponses(null);
			put.setSecurity(null);
			
			Delete delete =new Delete();
			delete.setTags("tags");
			delete.setSummary("deleting a Song");
			delete.setOperationId("deleteSong");
			delete.setRequestBody(null);
			delete.setResponses(null);
			delete.setSecurity(null);
			
			paths.setPost(post);
			paths.setGet(get);
			paths.setPut(put);
			paths.setDelete(delete);
			main1.setPaths(paths);
			
			ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
			mapper.writeValue(new File("C:\\Users\\Sai chandu\\Desktop\\accelarator\\xmltoyaml\\target\\dheja.yml"), main1);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
